
from agent.planner import generate_candidate_plans
from agent.activity_planner import select_activities
from agent.itinerary import build_itinerary
from agent.utility import extract_features, rule_based_utility
from environment.environment import Environment
from models.nn_model import load_model, train_model
import csv

class TourPlanningAgent:
    def __init__(self):
        self.env = Environment()
        self.model = load_model()

    def run(self, goals):
        candidates = generate_candidate_plans(self.env, goals)
        best_plan = None
        best_acts = []
        best_score = -1
        
        for plan in candidates:
            acts = select_activities(plan, self.env.get_activities(), goals)
            
            # Simple scoring
            score = rule_based_utility(plan, acts, goals)
            
            if score > best_score:
                best_score = score
                best_plan = plan
                best_acts = acts
        
        if not best_plan:
            return None, None, None
            
        itinerary = build_itinerary(best_plan["destinations"], best_acts)
        return best_plan, best_acts, itinerary

    def learn(self, plan, acts, g, rating):
        # Save to CSV for future training
        features = extract_features(plan, acts, g)
        with open('data/training_data.csv', 'a', newline='') as f:
            csv.writer(f).writerow(features + [rating])
