
def extract_features(plan, acts, g):
    cost = plan["price"] + plan["travel_cost"]
    days = plan["days"]
    travel = plan["travel_cost"]
    
    # Interest match ratio
    if not g["interests"]:
        im = 0
    else:
        im = len(set(g["interests"]) & set(plan["interests"])) / len(g["interests"])
        
    return [cost, days, travel, im, 0.5] # Simple dummy features

def rule_based_utility(plan, acts, g):
    total_cost = plan["price"] + plan["travel_cost"]
    if total_cost > g["budget"]:
        return 0 # Over budget is bad
    
    im_score = len(set(g["interests"]) & set(plan["interests"]))
    return im_score
