
def parse_user_query(text):
    text = text.lower()
    goals = {
        "budget": 1000,
        "days": 5,
        "interests": []
    }
    
    # Keyword extraction
    if "surf" in text or "beach" in text: goals["interests"].append("surfing"); goals["interests"].append("ocean")
    if "wildlife" in text or "safari" in text: goals["interests"].append("wildlife")
    if "culture" in text or "history" in text: goals["interests"].append("culture"); goals["interests"].append("history")
    if "hike" in text or "mountain" in text: goals["interests"].append("hiking"); goals["interests"].append("nature")
    
    # Simple number extraction
    words = text.split()
    for i, w in enumerate(words):
        if w.isdigit():
            val = int(w)
            if "day" in words[i+1] if i+1 < len(words) else False:
                goals["days"] = val
            elif val > 30: # Assumption: budget is usually > 30
                goals["budget"] = val
    
    return goals
