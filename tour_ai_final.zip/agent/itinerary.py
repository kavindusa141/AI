
def build_itinerary(route, selected_acts):
    itinerary = {}
    act_pool = selected_acts.copy()
    
    for day_num, city in enumerate(route, 1):
        day_acts = []
        # Find activities for this city in our selected list
        # We process the list to find matches
        remaining = []
        time_left = 8
        
        for a in act_pool:
            # Need to match activity to city (simplified here by name lookup or assumption)
            # In production, activity object should have 'city' key.
            # Here we assume the activity selection logic passed correct ones.
            # We assign linearly for simplicity in this demo.
            if time_left >= a["duration"]:
                day_acts.append(a)
                time_left -= a["duration"]
            else:
                remaining.append(a)
        
        act_pool = remaining
        itinerary[day_num] = {"city": city, "activities": day_acts}
        
    return itinerary
