
import random

def select_activities(plan, acts_db, goals):
    selected = []
    total_cost = 0
    plan_interests = set()
    
    for city in plan["destinations"]:
        available = acts_db.get(city, [])
        # Score activities based on interest match
        scored = []
        for a in available:
            score = 1 if a["interest"] in goals["interests"] else 0
            scored.append((score, a))
        
        # Pick top 2 activities per city
        scored.sort(key=lambda x: x[0], reverse=True)
        for score, a in scored[:2]:
            selected.append(a)
            total_cost += a["cost"]
            plan_interests.add(a["interest"])
            
    plan["price"] += total_cost
    plan["interests"] = list(plan_interests)
    return selected
