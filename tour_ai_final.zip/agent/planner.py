
import random

def generate_graph_route(cities_graph, start_node, days):
    route = [start_node]
    current = start_node
    
    for _ in range(days - 1):
        options = cities_graph[current]["connections"]
        # Simple heuristic: don't go back immediately if possible
        valid_options = [c for c in options if c not in route[-2:]]
        if not valid_options: valid_options = options
        
        next_city = random.choice(valid_options)
        route.append(next_city)
        current = next_city
        
    return route

def generate_candidate_plans(env, goals):
    # Generates 5 possible routes based on the graph
    cities = env.get_cities()
    plans = []
    
    start_nodes = ["Colombo", "Negombo"] # Airports
    
    for _ in range(5):
        start = random.choice(start_nodes)
        route = generate_graph_route(cities, start, goals["days"])
        
        # Structure it like a package object
        plan = {
            "destinations": route,
            "days": goals["days"],
            "price": 0, # Calculated later
            "interests": [], # Calculated later
            "travel_cost": goals["days"] * 50 # Approx $50/day transport
        }
        plans.append(plan)
        
    return plans
