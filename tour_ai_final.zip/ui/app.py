
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, render_template, request, jsonify
from agent.agent import TourPlanningAgent
from agent.nlp_processor import parse_user_query

app = Flask(__name__)
agent = TourPlanningAgent()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_msg = data.get("message", "")
    
    # 1. NLP Parse
    goals = parse_user_query(user_msg)
    
    # 2. Agent Run
    plan, acts, itinerary = agent.run(goals)
    
    if not plan:
        return jsonify({
            "response": "I couldn't find a route that fits those constraints. Try increasing the budget or days.",
            "itinerary": None
        })
    
    # 3. Format Response
    summary = f"I've planned a {goals['days']}-day trip covering: " + " -> ".join(plan['destinations'])
    return jsonify({
        "response": summary,
        "itinerary": itinerary,
        "goals_detected": goals
    })

if __name__ == "__main__":
    app.run(debug=True)
