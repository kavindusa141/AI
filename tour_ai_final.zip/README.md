# Sri Lankan Tour AI Agent (Finalized)
This agent uses a Graph-based planner and NLP to generate realistic Sri Lankan tours.

## How to Run
1. Install dependencies:
   pip install flask scikit-learn joblib

2. Run the Web UI:
   python ui/app.py

3. Open http://127.0.0.1:5000 in your browser.
