
import json
import os

class Environment:
    def __init__(self):
        with open('data/cities.json') as f:
            self.cities = json.load(f)
        with open('data/activities.json') as f:
            self.activities = json.load(f)
            
    def get_cities(self):
        return self.cities
        
    def get_activities(self):
        return self.activities
